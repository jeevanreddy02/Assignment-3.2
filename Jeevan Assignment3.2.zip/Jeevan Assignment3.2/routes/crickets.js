const express = require('express');
const router = express.Router();
const Cricket = require('../models/cricket');

// Get all players
router.get('/', async (req, res) => {
    try {
        const players = await Cricket.find();
        res.json(players);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get a specific player by ID
router.get('/:id', async (req, res) => {
    try {
        const player = await Cricket.findById(req.params.id);
        res.json(player);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/', async (req, res) => {
    const playersData = req.body; // Assuming req.body is an array of player objects

    try {
        const savedPlayers = await Cricket.insertMany(playersData);
        res.status(201).json(savedPlayers);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update a player by ID
router.patch('/:id', async (req, res) => {
    try {
        const player = await Cricket.findById(req.params.id);
        player.sub = req.body.sub;
        const updatedPlayer = await player.save();
        res.json(updatedPlayer);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a player by ID
exports.deletePlayer = function (req, res) {
    const playerId = req.params.id;
    Cricket.deleteOne({ _id: playerId }, function (err, result) {
        if (err) {
            res.status(500).json({ message: err.message });
        } else if (result.deletedCount === 0) {
            res.status(404).json({ message: 'Player not found' });
        } else {
            res.json({ message: 'Player deleted successfully' });
        }
    });
};


module.exports = router;
